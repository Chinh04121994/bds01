<div class="list-group">
    <a class="list-group-item active">Quản lý tài khoản</a>
    <a href="#" class="list-group-item" data-toggle="modal" data-target="#dangky">Đăng ký tài khoản</a>
    <a href="index.php?ttnd=1" class="list-group-item">Cập nhật tài khoản</a>
</div>
<div class="list-group">
    <a class="list-group-item active">Quản lý menu</a>
    <a href="#" class="list-group-item" data-toggle="modal" data-target="#menu_cha">Tạo thêm menu cha</a>
    <a href="index.php?ttnd=2" class="list-group-item">Cập nhật menu cha</a>
    <a href="#" class="list-group-item" data-toggle="modal" data-target="#menu_con">Tạo thêm menu con</a>
    <a href="index.php?ttnd=3" class="list-group-item">Cập nhật menu con</a>
    <a href="#" class="list-group-item" data-toggle="modal" data-target="#banner">Tạo thêm banner</a>
    <a href="index.php?ttnd=6" class="list-group-item">Cập nhật banner</a>
</div>
<div class="list-group">
    <a class="list-group-item active">Quản lý phần mục</a>
    <a href="#" data-toggle="modal" data-target="#muc_cha" class="list-group-item">Tạo thêm mục cha</a>
    <a href="index.php?ttnd=4" class="list-group-item">Cập nhật mục cha</a>
    <a href="#" class="list-group-item" data-toggle="modal" data-target="#muc_con">Tạo thêm mục con</a>
    <a href="index.php?ttnd=5" class="list-group-item">Cập nhật mục con</a>
</div>