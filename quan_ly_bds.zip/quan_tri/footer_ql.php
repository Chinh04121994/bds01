<div class="row well-sm bg-primary">
    <div class="col-md-12 text-center">
        Bản quyền thuộc Trường Cao Đẳng Kỹ Thuật Công Nghiệp Việt Nam - Hàn Quốc<br>
        Địa chỉ: Đường Hồ Tông Thốc - TP.Vinh - Tỉnh Nghệ An<br>
        Số điện thoại: 02383.3511454 *** Fax: 038.852194<br>
    </div>
</div>