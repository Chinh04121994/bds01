<div class="row bg-info">
    <div class="col-md-2 can_le">
        <?php
        include("menu_ql.php");
        ?>
    </div>
    <!----------------------------------->
    <div class="col-md-10 can_le">
        <?php
        include("noidung_ql.php");
        include_once("edit_ql.php");
        include("form_them_menu.php");
        ?>
    </div>
</div>