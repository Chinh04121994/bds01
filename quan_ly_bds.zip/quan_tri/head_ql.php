<div class="row well-sm bg-primary">
    <div class="row">
        <div class="col-md-12">
            <h2 class="text-center" style="text-shadow: 3px 2px rgb(180, 19, 19);"><b>QUYỀN QUẢN TRỊ ADMIN </b></h2>
        </div>
    </div>
</div>