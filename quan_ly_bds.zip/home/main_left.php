<div class="main-left">
    <?php
        include('home.php');
    ?>
</div>
 