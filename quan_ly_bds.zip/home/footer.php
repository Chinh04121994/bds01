<footer>
    <div class="footer-top">
        <div>
            <ul>liên kết website
                <li>facebook.com</li>
                <li>google ++</li>
                <li>twitter</li>
            </ul>
        </div>
        <div>
            <ul>về chúng tôi
                <li>giới thiệu</li>
                <li>bảng giá quảng cáo</li>

            </ul>
        </div>

        <div>
            <ul>trang thông tin dự án BDS01
                <li>hotline: 0123456789</li>
                <li>email: vanchinh@gmail.com</li>
                <li>địa chỉ: trường việt-hàn</li>
            </ul>
        </div>
    </div>
    <div class="footer-bottom">
        <p>© Copyright 2023 by văn chính</p>
    </div>
</footer>
