<div class="main">
    <?php
    include('main_left.php');
    include('main_right.php');
    ?>     
</div>
