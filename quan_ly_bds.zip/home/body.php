<body>

    <div class="container">
        <?php 
            include('header.php');
            include('main.php');
            include('footer.php');

        ?>
    </div>

</body>
